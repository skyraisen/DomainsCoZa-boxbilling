<?php
/*****************************************************
Author : Domains.co.za
Description : This file is used for configuration
regarding domain transfers and their notifications

******************************************************/


// Admin User who can access the WHMCS API
$adminUser = "administrator";

?>
